package service.wlt;

import static com.alibaba.fastjson2.util.TypeUtils.toBigDecimal;

/**
 *
 */
public class AccSvs {


}
