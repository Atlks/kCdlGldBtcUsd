package service;

import util.algo.Icall;

public class Trans2YLwltService extends  BaseService implements Icall {


    public void handle(Object dtoServicePrm) throws Exception {


    }


    /**
     * @param bo
     * @return
     * @throws Exception
     */
    @Override
    public Object main(Object bo) throws Exception {

        return bo;
    }
}
