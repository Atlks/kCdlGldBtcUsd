package service.secury;

/**
 * 入侵检测和防御系统（IDPS）：invst detect protes sys
 * 监控网络流量，检测和阻止恶意活动。
 */
public interface IDPS {
}
