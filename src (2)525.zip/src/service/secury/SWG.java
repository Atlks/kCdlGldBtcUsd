package service.secury;

/**
 * 安全Web网关（SWG）：secury web gate
 * 过滤和阻止恶意网站和内容，保护用户免受网络威胁。
 */
public interface SWG {
}
