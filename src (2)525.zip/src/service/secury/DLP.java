package service.secury;

/**
 * 数据丢失防护（DLP）： data lost protect
 * 检测和阻止敏感数据离开组织的网络。
 */
public interface DLP {
}
