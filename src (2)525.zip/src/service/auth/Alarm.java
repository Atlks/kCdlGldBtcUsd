package service.auth;

/**
 * sam 警报系统
 */
public interface Alarm {
}
