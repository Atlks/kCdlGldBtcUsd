package service;

public class BaseService {
}
