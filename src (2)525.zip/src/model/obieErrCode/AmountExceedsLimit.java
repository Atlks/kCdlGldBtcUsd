package model.obieErrCode;
//支付金额超过限额
public class AmountExceedsLimit extends Exception {
}
