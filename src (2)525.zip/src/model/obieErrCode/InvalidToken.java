package model.obieErrCode;

public class InvalidToken extends Exception {
}
