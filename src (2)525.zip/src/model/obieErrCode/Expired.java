package model.obieErrCode;

public class Expired extends Exception {
}
