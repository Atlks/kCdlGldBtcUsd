package model.obieErrCode;

/**
 * 资金暂时不可用，可能因挂账或冻结等原因
 */
//UK.OBIE.Payment.FundsUnavailable
public class FundsUnavailable extends  Exception {
}

