package model.obieErrCode;

//Consent 被用户撤销
public class Revoked  extends Exception {
}
