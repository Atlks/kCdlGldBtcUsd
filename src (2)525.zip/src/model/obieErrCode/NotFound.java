package model.obieErrCode;

public class NotFound extends  Exception {
}