package model.obieErrCode;

/**
 * UK.OBIE.Payment.InsufficientFunds
 */
public class InsufficientFunds extends Exception {
}
