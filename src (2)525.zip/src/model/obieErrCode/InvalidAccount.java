package model.obieErrCode;

public class InvalidAccount extends Exception {
}
