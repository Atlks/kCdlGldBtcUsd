package model.obieErrCode;

public class ProcessingFailed extends Exception {
}
