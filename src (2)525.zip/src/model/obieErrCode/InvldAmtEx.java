package model.obieErrCode;

public class InvldAmtEx extends RuntimeException {
    public InvldAmtEx(String s) {
        super(s);
    }
}
