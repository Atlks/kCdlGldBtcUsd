package model.wlt;

import java.math.BigDecimal;

public class TransOverviewSum {

    //已经充值总额
    public BigDecimal alreadyRechgSum=new BigDecimal(0);;
    public BigDecimal WthdrSum=new BigDecimal(0);;
    public BigDecimal ExchgSum=new BigDecimal(0);;
    //保险资金池总额
    public BigDecimal insFdPoolBalance=new BigDecimal(0);;
}
