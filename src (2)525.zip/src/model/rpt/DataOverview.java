//package model.rpt;
//
//import model.rpt_dataSmry.DataSummaryVo;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class DataOverview {
//
//    public DataSummaryVo DataSummary1;
//
//    public  List<RechgAmtSumNMbrs> lists=new ArrayList<>();
//}
