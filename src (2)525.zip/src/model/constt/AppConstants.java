package model.constt;

public class AppConstants {

    public static final String ROLE_ADMIN = "admin";
    public static final int MAX_RETRY = 3;
    public static final String DATE_FORMAT = "yyyy-MM-dd";
}
