package model.OpenBankingOBIE;

public enum StatementAmountType {
    Credit,
    Debit,
    BalanceTransfer,
//    CashMachine,
//    Cheque,
//    Counter,
//    DirectDebit,
//    Dividend,
    Fee,
 //   Interest,
 //   NotSpecified,
    Other,
    Payment,
 //   PointOfSale,
    Transfer,
//    StandingOrder,
//    BillPayment,
//    CreditCard,
    Adjustment,
  //  OnLine,
  //  Telephone
    xWithdrawal, xRechg

}


