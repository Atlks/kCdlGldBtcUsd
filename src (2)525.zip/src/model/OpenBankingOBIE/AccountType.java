package model.OpenBankingOBIE;


/**
 * BUSINESS.EMoney（如果是平台内资金）
 *  ins_fd_pool==biz.ins_fd_pool
 *  =buz.SavingsAccount
 */
public enum AccountType {
    PERSONAL ,
    BUSINESS ;


  //  public static String ins_fd_pool;
}
