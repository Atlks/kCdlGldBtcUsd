/**
 *   model pkg..dont need entity
 */
package model;


