package entityx.wlt;

import util.entty.PageDto;

public class QryRechgOrdReqDto extends PageDto {

   // @CurrentUsername
    public String uname="";   //like



}
