/**
 *   model pkg
 *   dep entty
 */
package entityx;


