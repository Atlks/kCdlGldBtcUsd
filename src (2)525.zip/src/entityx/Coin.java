package entityx;

//虚拟货币实体类
public class Coin {

    public  String name;   //名称列如btc eth
    public  double price;

    public Coin(String name, double price) {
  this.name=name;
  this.price=price;
    }
}
