package entityx.usr;

public class ReqDtoSetSecyQstn {
}
