package entityx.usr;

import lombok.Data;
import util.entty.PageDto;

@Data
public class ReqDtoQryUsr extends PageDto {

//    public int page =1;
//    public int pagesize =100;
    public  String unameKeyword ="";
}
