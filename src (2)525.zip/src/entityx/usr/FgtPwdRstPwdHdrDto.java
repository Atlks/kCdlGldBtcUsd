package entityx.usr;

import lombok.Data;


@Data
public class FgtPwdRstPwdHdrDto {
    public String uname;
    public String answer;
    public String newpwd;
}
