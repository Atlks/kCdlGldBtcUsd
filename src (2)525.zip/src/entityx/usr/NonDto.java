package entityx.usr;

public class NonDto {
}
