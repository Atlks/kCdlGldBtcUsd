/**
 *  api层接口 ，web接口..pkg handler...dep name api
 *  Serverless 系统不仅用 API Gateway + 函数取代了传统的 Controller
 *  内建日志采集（console 2 log.file）、错误追踪集成
 */
package api;


