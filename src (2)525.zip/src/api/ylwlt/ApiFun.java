package api.ylwlt;

public @interface ApiFun {
}
