/**
 *  加密货币 金属货币贵金属 外汇 大宗商品实物货币
 */
package api.coin;


