
/**
 *  主钱包方面接口
 *  @author ati
 */
package api.wlt;


