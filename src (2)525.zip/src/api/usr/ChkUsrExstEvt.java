//package api.usr;
//
//import handler.usr.dto.RegDto;
//// org.springframework.context.ApplicationEvent;
//
//public class ChkUsrExstEvt extends ApplicationEvent {
//    public ChkUsrExstEvt(RegDto dtoReg) {
//        super(dtoReg);
//    }
//}
