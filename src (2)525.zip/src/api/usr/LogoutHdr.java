//package api.usr;
//
//import entityx.usr.NonDto;
//import jakarta.annotation.security.PermitAll;
//import jakarta.ws.rs.Path;
//import util.algo.Icall;
//
//import static util.misc.util2026.setcookie;
//import static util.serverless.ApiGateway.httpExchangeCurThrd;
//@PermitAll
//@jakarta.annotation.security.RolesAllowed("user")
//
//public class LogoutHdr{
//
//@Path("/logout")
//    public static Object main(NonDto dto) throws Exception {
//       // setcookie("uname","",httpExchangeCurThrd.get());
//
//        return "ok";
//    }
//}
