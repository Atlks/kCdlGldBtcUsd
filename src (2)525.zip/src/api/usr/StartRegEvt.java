//package api.usr;
//
//import handler.usr.dto.RegDto;
//import org.springframework.context.ApplicationEvent;
//
//public class StartRegEvt extends ApplicationEvent {
//    public StartRegEvt(RegDto dtoReg) {
//        super(dtoReg);
//    }
//}
