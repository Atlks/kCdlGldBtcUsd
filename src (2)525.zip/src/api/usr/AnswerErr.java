package api.usr;

public class AnswerErr extends Throwable {
    public AnswerErr(String s) {
    }
}
