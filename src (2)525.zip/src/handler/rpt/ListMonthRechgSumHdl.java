package handler.rpt;

import entityx.usr.NonDto;
import util.model.Context;
import util.serverless.ApiGatewayResponse;
import util.serverless.RequestHandler;

public class ListMonthRechgSumHdl  implements RequestHandler<NonDto, ApiGatewayResponse> {
    /**
     * @param param
     * @param context
     * @return
     * @throws Throwable
     */
    @Override
    public ApiGatewayResponse handleRequest(NonDto param, Context context) throws Throwable {


        return null;
    }
}
