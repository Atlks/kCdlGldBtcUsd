package handler.rpt;


/**
 * menu.admin/data rpt /rank
 *
 */
public class MbrAgtSumRpt {
}
