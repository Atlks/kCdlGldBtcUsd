//package handler.fundDetail;
//
//
///**
// * menu::  admin/data rpt/fd dtl
// */
//public class QryFundDtlHdl {
//}
