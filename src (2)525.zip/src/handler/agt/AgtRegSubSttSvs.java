package handler.agt;

public class AgtRegSubSttSvs {


    /**
     * drktlSub  indrkSub  allSub

     * @param u
     * @param session
     */
//    public  void updtSubCnt(  Usr u, Session session) throws Throwable {
//
//        //drktl sub reg cnt already up
//        new AgtRegSubSttSvs().updateAllSupCnt(u,session);
//        updateIndirectSubordinatesOnNewUser(u.uname);
//    }






}
