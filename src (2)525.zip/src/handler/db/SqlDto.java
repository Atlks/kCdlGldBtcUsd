package handler.db;

import lombok.Data;

@Data
public class SqlDto {
    public  String sql="";
}
