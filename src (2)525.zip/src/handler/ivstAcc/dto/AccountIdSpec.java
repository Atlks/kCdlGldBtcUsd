package handler.ivstAcc.dto;
//'invd_fd_pool'
public enum AccountIdSpec {
    invd_fd_pool

}
