package handler.ivstAcc.dto;

import util.entty.PageDto;

/**
 * 订单号              会员账号                    标签             VIP等级          上级代理               提现金额           到账金额              审核状态            审核人                    提现时间                         审核时间
 */
public class WthdrawReviewQryDto extends PageDto {
}
