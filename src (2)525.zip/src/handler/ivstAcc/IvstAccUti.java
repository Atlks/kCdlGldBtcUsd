package handler.ivstAcc;

// static cfg.AppConfig.sessionFactory;


public class IvstAccUti {


}
