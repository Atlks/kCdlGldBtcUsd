//package handler;
//
//import io.milton.http.ResourceFactory;
//import io.milton.resource.Resource;
//
//public class MyResourceFactory implements ResourceFactory {
//    @Override
//    public Resource getResource(String host, String path) {
//        // 根据 path 返回文件资源
//        return new MyFileResource(path);
//    }
//}
