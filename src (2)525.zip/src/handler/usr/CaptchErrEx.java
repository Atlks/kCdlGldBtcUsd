package handler.usr;

public class CaptchErrEx extends Throwable {
    public CaptchErrEx(String s) {
    }
}
