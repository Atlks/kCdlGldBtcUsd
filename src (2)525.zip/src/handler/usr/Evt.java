package handler.usr;

public enum Evt {
   reg,login,rchg,wthdr,transact
}
