package handler.usrStt;

import java.math.BigDecimal;
import java.util.List;
// 数据报表》排行榜
public class RankRptVo {

   // public BigDecimal rechgSum;
    public List<?>  totalRechg_mbrList;
    public List<?>  totalRechg_agtList;


//public BigDecimal totalWthdr;

    public List<?>  totalWthdr_mbrList;
    public List<?>  totalWthdr_agtList;


  //  public BigDecimal totalEchxg;

    public List<?> totalEchxg_mbrList;
    public List<?>  totalEchxg_agtList;
 //   public BigDecimal totalCms;

    public List<?> totalProfit_mbrList;
    public List<?>  totalProfit_agtList;


}
