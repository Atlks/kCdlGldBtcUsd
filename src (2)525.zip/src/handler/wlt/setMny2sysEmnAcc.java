//package handler.wlt;
//
//public class setMny2sysEmnAcc {
//    public setMny2sysEmnAcc(AddMoneyDto ) {
//    }
//}
