package handler.wlt;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class AddMoneyDto {

     public String accID;
    public  BigDecimal amt;
}
