package handler;

public class ExecFailEx extends Throwable {
    public ExecFailEx(String s) {
        super(s);
    }
}
