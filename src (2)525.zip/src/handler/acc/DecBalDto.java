package handler.acc;

import handler.wlt.DepositDto;

/**
 *  public String accid;
 *     public BigDecimal amt;
 *     public TransactionCode type;
 */
public class DecBalDto extends DepositDto {
}
