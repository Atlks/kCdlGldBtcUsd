package handler.cms;

public class ListMyCmsLog {
}
