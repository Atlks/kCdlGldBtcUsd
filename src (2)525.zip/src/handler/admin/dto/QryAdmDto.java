package handler.admin.dto;

import lombok.Data;

@Data
public class QryAdmDto {
    public String uname;
}
