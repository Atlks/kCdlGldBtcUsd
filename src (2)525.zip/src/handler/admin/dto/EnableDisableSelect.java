package handler.admin.dto;

public record EnableDisableSelect(String uname,boolean enable) {

}
