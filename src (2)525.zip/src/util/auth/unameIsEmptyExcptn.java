package util.auth;

public class unameIsEmptyExcptn extends Throwable {
    public unameIsEmptyExcptn(String s) {
    }
}
