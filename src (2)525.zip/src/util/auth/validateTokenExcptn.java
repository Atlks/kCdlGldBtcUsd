package util.auth;

public class validateTokenExcptn extends Throwable {
    public validateTokenExcptn(String s) {
    }
}
