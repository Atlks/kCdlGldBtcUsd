package util.auth;

public class IsEmptyEx extends Exception {
    public IsEmptyEx(String msg ) {
   super(msg);
    }
}
