package util.auth;

public class CantGetTokenJwtEx extends Exception {
    public CantGetTokenJwtEx(String authorizationTokenCantGet) {

    }
}
