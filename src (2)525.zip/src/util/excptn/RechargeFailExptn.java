package util.excptn;

public class RechargeFailExptn extends Exception {
    public RechargeFailExptn(String s) {
  super(s);
    }
}
