package util.excptn;

public class AreadyProcessedEx  extends Exception {
    public AreadyProcessedEx(String s) {
  super(s);
    }
}
