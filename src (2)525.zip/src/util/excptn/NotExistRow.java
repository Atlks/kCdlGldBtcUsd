package util.excptn;

public class NotExistRow extends Throwable {
    public NotExistRow(String s) {
        super(s);
    }
}
