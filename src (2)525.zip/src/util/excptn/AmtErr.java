package util.excptn;

public class AmtErr extends RuntimeException {
    public AmtErr(String s) {
        super(s);
    }
}
