package util.ex;

import util.excptn.ExceptionObj;

public class LoginEx extends ExceptionObj {
    public LoginEx(String msg
    ) {
        super(msg);
    }
}
