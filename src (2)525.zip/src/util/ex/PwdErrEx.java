package util.ex;

import util.excptn.ExceptionObj;

public class PwdErrEx extends ExceptionObj {
    public PwdErrEx(String s) {
   super(s);
    }
}
