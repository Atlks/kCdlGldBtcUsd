package util.ex;

public class ErrAdjstTypeEx  extends  Exception{
    public ErrAdjstTypeEx(String s) {
    }
}
