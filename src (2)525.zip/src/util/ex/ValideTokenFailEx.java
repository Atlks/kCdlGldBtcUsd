package util.ex;



import util.excptn.ExceptionObj;

public class ValideTokenFailEx extends ExceptionObj {
    public ValideTokenFailEx(String s) {
        super(s);
    }
}
