package util.ex;

import util.excptn.ExceptionObj;

public class BalanceNotEnghou extends Exception {
    public BalanceNotEnghou(String s) {
   super(s);
    }
}
