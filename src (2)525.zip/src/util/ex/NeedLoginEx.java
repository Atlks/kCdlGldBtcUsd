package util.ex;

import util.excptn.ExceptionObj;

public class NeedLoginEx extends ExceptionObj {
    public NeedLoginEx(String s) {
  super(s);
    }
}
