package util.ex;

public class encryptAesEx extends RuntimeException {
    public encryptAesEx(String s, Exception e) {
   super(s,e);
    }
}
