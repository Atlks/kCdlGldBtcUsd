package util.ex;

public class PwdNotEqExceptn extends Throwable {
    public PwdNotEqExceptn(String s) {
        super(s);
    }
}
