package util.ex;

import util.excptn.ExceptionObj;

public class ParseEx  extends ExceptionObj {
    public ParseEx(String s) {
        super(s);
    }
}
