package util.evtdrv;

public class AnotherEvent {
    public String getData() {
        return "";
    }
}
