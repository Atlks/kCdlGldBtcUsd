package util.entty;

import lombok.Data;

@Data
public class FgtPwdGetAnswerByUnameDto {
    public String uname;

}
