package util.evt;

import model.usr.Usr;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class RegEvt {

    public static List<Consumer<Usr>> evtlist4reg=new ArrayList<>();

}
