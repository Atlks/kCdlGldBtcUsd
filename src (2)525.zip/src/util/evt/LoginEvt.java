package util.evt;

import model.usr.Usr;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class LoginEvt {


    public static List<Consumer<Usr>> evtlist4login=new ArrayList<>();

}
