package util.annos;

public @interface Blankable {
}
