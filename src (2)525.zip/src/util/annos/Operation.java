package util.annos;

public @interface Operation {
    String summary();

    String example();
}
