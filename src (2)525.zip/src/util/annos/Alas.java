package util.annos;

public @interface Alas {
    String value() default "";
}
