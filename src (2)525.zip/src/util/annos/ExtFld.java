package util.annos;

public @interface ExtFld {
}
