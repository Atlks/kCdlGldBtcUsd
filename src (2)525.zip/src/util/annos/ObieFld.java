package util.annos;

public @interface ObieFld {
    String value() default "";
}
