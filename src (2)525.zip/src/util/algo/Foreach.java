package util.algo;

public class Foreach {
}
