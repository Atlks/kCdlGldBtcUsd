package util.algo;

public class PrintUtil {
}
