package util.algo;

public class IfUtil {
}
