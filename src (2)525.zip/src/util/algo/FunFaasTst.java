package util.algo;

public class FunFaasTst {

    public static void main(String[] args) {

    }
}
