package util.cache;

public class CantFindFileEx extends Exception {
    public CantFindFileEx(String s) {super(s);
    }
}
