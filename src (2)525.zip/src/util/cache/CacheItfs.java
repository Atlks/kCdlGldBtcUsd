package util.cache;

public interface CacheItfs {
}
